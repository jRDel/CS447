from django.shortcuts import render
from django.http import HttpResponse
from . import models
import subprocess

# Create your views here.

def index(request):
	host = models.Host.objects.all().first()
	return HttpResponse(f'It works. {request.headers}\n HOST: {host.mac_address}\n')

def hostname(request):
	cmd = ['hostname']
	result = subprocess.run(cmd, capture_output=True, text=True)
	return HttpResponse(result.stdout)
