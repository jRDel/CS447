from django.apps import AppConfig


class RdnsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rdns'
