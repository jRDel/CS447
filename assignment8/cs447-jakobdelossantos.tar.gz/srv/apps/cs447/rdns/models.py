from django.db import models
from datetime import datetime

# Create your models here.
class Host(models.Model):
	mac_address = models.CharField(max_length=255, null=True, blank=True)
	hostname = models.CharField(max_length=255, null=True, blank=True)
	nmap_hostname = models.CharField(max_length=255, null=True, blank=True)
	ip_address = models.CharField(max_length=255, default = 'ipdefault')
	online = models.BooleanField(default=False)
	last_update = models.DateTimeField(default=datetime.now, blank=True)
