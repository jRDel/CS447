#!/bin/bash

nmap -sS -p 80 -oX output.xml 10.0.100.0/24

./parse.py output.xml
